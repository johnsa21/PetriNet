import snakes.plugins
snakes.plugins.load("gv", "snakes.nets", "nets")
from snakes.nets import *

#adding the places to the PetriNet
pn = PetriNet("VehicleGasCompression")
pn.add_place(Place("gnv_supply", [dot], None))
pn.add_place(Place("compression1"))
pn.add_place(Place("heat_exchange1"))
pn.add_place(Place("compression2", ))
pn.add_place(Place("heat_exchange2"))
pn.add_place(Place("storage"))

#adding the transitions to the PetriNet
pn.add_transition(Transition("T1"))
pn.add_transition(Transition("T2"))
pn.add_transition(Transition("T3"))
pn.add_transition(Transition("T4"))
pn.add_transition(Transition("T5"))

#adding arcs to the PetriNet
pn.add_input("gnv_supply", "T1", Value(dot))
pn.add_output("compression1", "T1", Value(dot))
pn.add_input("compression1", "T2", Value(dot))
pn.add_output("heat_exchange1", "T2", Value(dot))
pn.add_input("heat_exchange1", "T3", Value(dot))
pn.add_output("compression2", "T3", Value(dot))
pn.add_input("compression2", "T4", Value(dot))
pn.add_output("heat_exchange2", "T4", Value(dot))
pn.add_input("heat_exchange2", "T5", Value(dot))
pn.add_output("storage", "T5", Value(dot))

#configurando o estado inicial da rede de Petri
pn.set_marking(Marking(gnv_supply=MultiSet([dot]), 
                       compression1=MultiSet([]),
                       heat_exchange1=MultiSet([]),
                       compression2=MultiSet([]),
                       heat_exchange2=MultiSet([]),
                       storage=MultiSet([])
                       )
               )

#armazenando o estado inicial numa variavel
graph = StateGraph(pn)